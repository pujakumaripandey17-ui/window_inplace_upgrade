# Windows Server 2016 Standard Desktop assessment

Assessment only. No ISO mounting, compatibility scan, VMware snapshot, backup, or upgrade.

## Requirements
- Ansible controller with `ansible.windows` collection and `pywinrm` installed.
- Windows Server 2016 target accessible via WinRM, with an account that has local admin rights.
- An approved maintenance window if `upgrade_reboot_if_pending: true`.
- Inventory credentials in `hosts.ini` are placeholders; use Ansible Vault in production.

## Run
`ansible-playbook -i /home/ansible/hosts.ini assessment.yml`

If the inventory is in this directory: `ansible-playbook -i hosts.ini assessment.yml`

## Output
- Target: `C:\WindowsUpgrade\Baseline\assessment.json`
- Controller: `reports/<inventory_hostname>-assessment.json`

## Notes
- 50 GB free space is a configurable operational threshold, not a universal Microsoft minimum.
- Failover Clustering feature presence is conservatively blocked; tailor this for your approved cluster runbook.
- Source language, media image and Windows Setup scan are validated in the separate compatibility stage.
- Auto-reboot is potentially disruptive. Run only with maintenance approval.
- `Get-WindowsFeature` requires ServerManager availability on the Windows Server target.
