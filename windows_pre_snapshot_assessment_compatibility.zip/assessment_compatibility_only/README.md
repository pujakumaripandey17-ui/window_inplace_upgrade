# Pre-snapshot Windows Server upgrade readiness

Scope: Windows Server 2016 Standard Desktop Experience -> Windows Server 2022 Standard Desktop Experience.
Only assessment and compatibility roles. No snapshots, backups, or actual OS upgrade.

## Configure
1. Edit `hosts.ini` with your hosts and WinRM account. Plaintext passwords are risky: use Ansible Vault where possible.
2. Place the approved ISO at `C:\WindowsUpgrade\Windows_Server_2022.iso` on each server.
3. Replace `upgrade_iso_sha256` in `upgrade_readiness.yml` with the approved SHA-256 hash.
4. Use an approved maintenance window: the assessment role reboots once if a pending reboot is detected.

## Run
`ansible-playbook -i /absolute/path/hosts.ini upgrade_readiness.yml`

Reports: `reports/<host>-assessment.json`, `reports/<host>-compatibility.json`.
If assessment fails, compatibility does not run for that host. If either fails, the host is NOT eligible for the next snapshot/backup stage. A downstream orchestration pipeline must gate on both successes; this playbook does not run that stage.

## Important limitations
- The 50 GB threshold is an operational policy setting, not a universal Microsoft minimum.
- This role checks the presence of a Standard Desktop Experience image, but does not fully validate OS installation language or whether Setup chooses the correct image index. Confirm language, edition and licensing with approved media and pilot tests.
- `Get-WindowsImage` requires DISM PowerShell support on targets.
- Native Setup scan-only exit code 0xC1900210 is accepted as compatibility success. Review Panther logs for failures.
- Application owner approval, backup readiness and snapshot checks belong to later stages.
- No guarantee for every workload; test on representative Windows Server 2016 machines before production.
