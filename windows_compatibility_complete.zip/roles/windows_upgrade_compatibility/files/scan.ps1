param(
    [Parameter(Mandatory = $true)][string]$IsoPath,
    [Parameter(Mandatory = $true)][string]$ExpectedSha256,
    [Parameter(Mandatory = $true)][string]$LogDirectory,
    [Parameter(Mandatory = $true)][string]$ReportPath,
    [ValidateSet('enable','disable')][string]$DynamicUpdateMode = 'disable'
)

$ErrorActionPreference = 'Stop'
$mountedHere = $false
$report = [ordered]@{
    computer_name       = $env:COMPUTERNAME
    scan_time_utc       = [DateTime]::UtcNow.ToString('o')
    compatible          = $false
    reason              = 'Scan not started'
    exit_code_hex       = 'N/A'
    iso_path            = $IsoPath
    sha256_verified     = $false
    source_os           = $null
    source_edition      = $null
    source_install_type = $null
    target_image        = $null
    target_image_index  = $null
    media_images        = @()
    dynamic_update      = $DynamicUpdateMode
    setup_log_directory = $LogDirectory
}

try {
    New-Item -Path $LogDirectory -ItemType Directory -Force | Out-Null
    New-Item -Path (Split-Path -Parent $ReportPath) -ItemType Directory -Force | Out-Null

    if (-not (Test-Path -LiteralPath $IsoPath -PathType Leaf)) {
        throw "ISO file not found: $IsoPath"
    }
    if ($ExpectedSha256 -notmatch '^[a-fA-F0-9]{64}$') {
        throw 'ExpectedSha256 must be a 64-character hexadecimal SHA256 value.'
    }

    # A single SHA256 read per scan; never trust an unverified ISO.
    $actualHash = (Get-FileHash -LiteralPath $IsoPath -Algorithm SHA256).Hash
    if ($actualHash -ine $ExpectedSha256) {
        throw "ISO SHA256 mismatch. Actual: $actualHash"
    }
    $report.sha256_verified = $true

    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $report.source_os = $os.Caption
    if ([int]$os.BuildNumber -ne 14393 -or $os.Caption -notmatch 'Windows Server 2016') {
        throw "Unsupported source OS: $($os.Caption) build $($os.BuildNumber). Expected Windows Server 2016."
    }
    if ($os.OSArchitecture -notmatch '64') {
        throw 'Source OS must be 64-bit.'
    }

    $cv = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    $report.source_edition = [string]$cv.EditionID
    $report.source_install_type = [string]$cv.InstallationType
    if ($report.source_edition -ne 'ServerStandard') {
        throw "Source edition must be ServerStandard (non-Evaluation), found: $($report.source_edition)"
    }
    if ($report.source_install_type -ne 'Server') {
        throw "Source installation must be Desktop Experience (InstallationType=Server), found: $($report.source_install_type)"
    }

    $diskImage = Get-DiskImage -ImagePath $IsoPath
    if (-not $diskImage.Attached) {
        Mount-DiskImage -ImagePath $IsoPath -ErrorAction Stop | Out-Null
        $mountedHere = $true
    }

    $volumes = @(Get-DiskImage -ImagePath $IsoPath | Get-Volume | Where-Object { $_.DriveLetter })
    if ($volumes.Count -ne 1) { throw 'Expected exactly one ISO volume with a drive letter.' }
    $root = '{0}:\' -f $volumes[0].DriveLetter
    $setup = Join-Path $root 'setup.exe'
    if (-not (Test-Path -LiteralPath $setup -PathType Leaf)) {
        throw "Windows Setup not found: $setup"
    }

    $install = @('sources\install.wim','sources\install.esd') |
        ForEach-Object { Join-Path $root $_ } |
        Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } |
        Select-Object -First 1
    if (-not $install) { throw 'Neither sources\install.wim nor sources\install.esd found.' }

    $images = @(Get-WindowsImage -ImagePath $install -ErrorAction Stop)
    $report.media_images = @($images | Select-Object ImageName, ImageIndex)

    # Require explicit Desktop Experience in the image name; reject Core and ambiguous media.
    $candidates = @($images | Where-Object {
        $_.ImageName -match 'Windows Server 2022' -and
        $_.ImageName -match 'Standard' -and
        $_.ImageName -match 'Desktop Experience' -and
        $_.ImageName -notmatch 'Datacenter|Evaluation|Azure Edition'
    })
    if ($candidates.Count -ne 1) {
        throw "Expected exactly one Windows Server 2022 Standard (Desktop Experience) image; found $($candidates.Count). Inspect media_images."
    }
    $report.target_image = [string]$candidates[0].ImageName
    $report.target_image_index = [int]$candidates[0].ImageIndex

    # Windows Setup is the final authority on language, applications, drivers and migration path.
    $arguments = @(
        '/auto', 'upgrade',
        '/quiet',
        '/eula', 'accept',
        '/compat', 'scanonly',
        '/dynamicupdate', $DynamicUpdateMode,
        '/copylogs', ('"{0}"' -f $LogDirectory)
    )
    $report.reason = 'Windows Setup compatibility scan started'
    $process = Start-Process -FilePath $setup -ArgumentList $arguments -Wait -PassThru -ErrorAction Stop
    $exitUnsigned = [BitConverter]::ToUInt32([BitConverter]::GetBytes([int32]$process.ExitCode), 0)
    $hex = '0x{0:X8}' -f $exitUnsigned
    $report.exit_code_hex = $hex

    switch ($hex) {
        '0xC1900210' { $report.compatible = $true; $report.reason = 'Native Windows Setup compatibility scan passed' }
        '0xC1900208' { $report.reason = 'Application or driver compatibility blocker' }
        '0xC1900204' { $report.reason = 'Requested migration choice is unavailable' }
        '0xC1900200' { $report.reason = 'System requirements not met' }
        '0xC190020E' { $report.reason = 'Insufficient disk space' }
        default { $report.reason = "Setup scan did not confirm compatibility (exit $hex); inspect Panther/Setup logs" }
    }
}
catch {
    $report.compatible = $false
    $report.reason = $_.Exception.Message
}
finally {
    if ($mountedHere) {
        try {
            Dismount-DiskImage -ImagePath $IsoPath -ErrorAction Stop | Out-Null
        }
        catch {
            $report.compatible = $false
            $report.reason += "; ISO dismount failed: $($_.Exception.Message)"
        }
    }

    try {
        $parent = Split-Path -Parent $ReportPath
        if (-not (Test-Path -LiteralPath $parent)) {
            New-Item -Path $parent -ItemType Directory -Force | Out-Null
        }
        $report.scan_time_utc = [DateTime]::UtcNow.ToString('o')
        $report | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ReportPath -Encoding UTF8 -Force
    }
    catch {
        $report.compatible = $false
        $report.reason += "; JSON report write failed: $($_.Exception.Message)"
    }
    $Ansible.Result = $report
}
