param([int]$MinimumFreeSpaceGB = 50)
$ErrorActionPreference = 'Stop'
$os = Get-CimInstance Win32_OperatingSystem
$computer = Get-CimInstance Win32_ComputerSystem
$cv = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
$disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$($os.SystemDrive)'"
if (-not $disk) { throw 'System disk could not be queried' }
$blockers = @()
if ($os.BuildNumber -ne '14393' -or $os.Caption -notmatch 'Windows Server 2016') { $blockers += 'Source must be Windows Server 2016 build 14393' }
if ($cv.EditionID -ne 'ServerStandard' -or $os.Caption -match 'Evaluation') { $blockers += 'Source must be non-Evaluation Standard edition' }
if ($cv.InstallationType -ne 'Server') { $blockers += 'Source must be Desktop Experience (InstallationType=Server)' }
if ($os.OSArchitecture -notmatch '64') { $blockers += '64-bit operating system required' }
if ($computer.DomainRole -ge 4) { $blockers += 'Domain controllers need a separate procedure' }
$cluster = Get-WindowsFeature -Name Failover-Clustering -ErrorAction Stop
if ($cluster.Installed) { $blockers += 'Failover clustering installed; requires a separate procedure' }
$reboot = @()
foreach ($key in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')) {
 if (Test-Path -LiteralPath $key) { $reboot += $key }
}
$sm = Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'
if ($sm.PendingFileRenameOperations) { $reboot += 'PendingFileRenameOperations' }
if ($reboot.Count -gt 0) { $blockers += 'Reboot remains pending after the permitted reboot' }
$freeGB = [math]::Round($disk.FreeSpace / 1GB, 2)
if ($freeGB -lt $MinimumFreeSpaceGB) { $blockers += "Free space $freeGB GB is below $MinimumFreeSpaceGB GB" }
if (Get-Process -Name setup,setuphost,setupprep -ErrorAction SilentlyContinue) { $blockers += 'Windows Setup process is already running' }
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { $blockers += 'Session is not elevated administrator' }
$services = @(Get-CimInstance Win32_Service | Where-Object { $_.StartMode -eq 'Auto' } | Select-Object Name,State,StartMode)
$Ansible.Result = [ordered]@{
 eligible = ($blockers.Count -eq 0)
 blockers = @($blockers)
 hostname = $env:COMPUTERNAME
 os = $os.Caption
 build = $os.BuildNumber
 edition = $cv.EditionID
 installation_type = $cv.InstallationType
 architecture = $os.OSArchitecture
 system_drive = $os.SystemDrive
 free_space_gb = $freeGB
 pending_reboot_reasons = @($reboot)
 domain = $computer.Domain
 automatic_services = $services
 captured_utc = (Get-Date).ToUniversalTime().ToString('o')
}
