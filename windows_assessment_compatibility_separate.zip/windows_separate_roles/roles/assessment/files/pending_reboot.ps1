$ErrorActionPreference = 'Stop'
$reasons = @()
foreach ($path in @(
  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')) {
  if (Test-Path -LiteralPath $path) { $reasons += $path }
}
$sm = Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -ErrorAction Stop
if ($sm.PendingFileRenameOperations) { $reasons += 'PendingFileRenameOperations' }
$Ansible.Result = @{ pending = ($reasons.Count -gt 0); reasons = @($reasons) }
