param(
 [string]$IsoPath,
 [string]$ExpectedSha256,
 [string]$LogDirectory,
 [ValidateSet('enable','disable')][string]$DynamicUpdateMode = 'disable'
)
$ErrorActionPreference = 'Stop'
$report = [ordered]@{ compatible=$false; reason='Not run'; exit_code_hex='N/A'; iso_path=$IsoPath; log_directory=$LogDirectory; media_images=@() }
$mountedHere = $false
try {
 if (-not (Test-Path -LiteralPath $IsoPath -PathType Leaf)) { throw 'ISO file not found' }
 $actualHash = (Get-FileHash -LiteralPath $IsoPath -Algorithm SHA256).Hash
 if ($actualHash -ine $ExpectedSha256) { throw 'ISO SHA256 mismatch' }
 $image = Get-DiskImage -ImagePath $IsoPath -ErrorAction Stop
 if (-not $image.Attached) { Mount-DiskImage -ImagePath $IsoPath -ErrorAction Stop | Out-Null; $mountedHere = $true }
 $volume = Get-DiskImage -ImagePath $IsoPath | Get-Volume
 if (-not $volume.DriveLetter) { throw 'ISO drive letter unavailable' }
 $root = "$($volume.DriveLetter):\"
 $setup = Join-Path $root 'setup.exe'
 if (-not (Test-Path -LiteralPath $setup)) { throw 'setup.exe missing' }
 $install = @('sources\install.wim','sources\install.esd') | ForEach-Object { Join-Path $root $_ } | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
 if (-not $install) { throw 'install.wim/install.esd missing' }
 $images = @(Get-WindowsImage -ImagePath $install -ErrorAction Stop)
 $report.media_images = @($images | Select-Object ImageName,ImageIndex)
 $target = @($images | Where-Object { $_.ImageName -match 'Windows Server 2022' -and $_.ImageName -match 'Standard' -and $_.ImageName -match 'Desktop Experience' -and $_.ImageName -notmatch 'Evaluation' })
 if ($target.Count -eq 0) { throw 'ISO does not advertise Windows Server 2022 Standard Desktop Experience image' }
 New-Item -Path $LogDirectory -ItemType Directory -Force | Out-Null
 $args = @('/auto','upgrade','/quiet','/compat','scanonly','/dynamicupdate',$DynamicUpdateMode,'/copylogs',('"' + $LogDirectory + '"'))
 $proc = Start-Process -FilePath $setup -ArgumentList $args -Wait -PassThru -ErrorAction Stop
 $hex = '0x{0:X8}' -f ([uint32]([int64]$proc.ExitCode -band 0xFFFFFFFFL))
 $report.exit_code_hex = $hex
 $report.compatible = ($hex -eq '0xC1900210')
 $report.reason = switch ($hex) {
  '0xC1900210' { 'Native scan passed' }
  '0xC1900208' { 'Application or driver blocker' }
  '0xC1900204' { 'Migration choice unavailable' }
  '0xC1900200' { 'System requirements not met' }
  '0xC190020E' { 'Insufficient free space' }
  default { 'Scan not confirmed successful; inspect Setup logs' }
 }
} catch { $report.reason = $_.Exception.Message }
finally {
 if ($mountedHere) {
  try { Dismount-DiskImage -ImagePath $IsoPath -ErrorAction Stop | Out-Null }
  catch { $report.compatible=$false; $report.reason += '; could not dismount ISO: ' + $_.Exception.Message }
 }
 $Ansible.Result = $report
}
