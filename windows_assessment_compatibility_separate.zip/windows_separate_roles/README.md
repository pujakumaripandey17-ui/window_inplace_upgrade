# Separate assessment and compatibility roles

1. Edit `hosts.ini` with resolvable Windows server names and credentials. Protect credentials with Ansible Vault for production.
2. The assessment playbook runs only the assessment role; if pending reboot is detected, it restarts once and reassesses.
3. The compatibility playbook runs only the compatibility role. ISO must already be staged on each target, and `upgrade_iso_sha256` must be set to the approved 64-character hash. It mounts the ISO, checks that a 2022 Standard Desktop image is present, and runs Windows Setup `/compat scanonly`.
4. Run:

    ansible-playbook -i /full/path/hosts.ini assessment.yml
    ansible-playbook -i /full/path/hosts.ini compatibility.yml

Reports: `reports/<host>-assessment.json` and `reports/<host>-compatibility.json`.

Run compatibility only on hosts that passed assessment. Separate invocations do not automatically filter out failed assessment hosts. No snapshot, backup, or actual OS upgrade is performed. Approval of application support, media language and licensing remains external. A detected Standard Desktop image on multi-index media does not prove Setup will select that image automatically. Pilot test before production. WinRM HTTP/NTLM inventory is an example; prefer WinRM HTTPS when available.
