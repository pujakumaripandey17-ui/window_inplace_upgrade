SCCM reinstall after October baseline, based on the five latest attachments

Observed failure in logs.txt:
- Target PHTWISBTST05; effective collection membership became true.
- Expected deployment policy was received.
- Action Scan then failed at TriggerSchedule ...113 with HRESULT 0x80041002 (Not found), after five attempts.
- This does not prove that the entire SMS_Client namespace is missing: earlier policy actions ran. Missing/uninitialized scan policy, disabled Software Updates client settings or client damage need distinction.
- The supplied latest files contain no reinstall call. The original project entry had reinstall commented out; the earlier October fix also omitted it. This bundle explicitly adds it before patching preflight.

IMPORTANT: the log is executing this different role path:
roles/windows_upgrade_patching_prerequisite/tasks/round.yml
It is NOT executing roles/windows_upgrade_sccm_patching in the attached log.
Update the role that your current playbook actually includes. Editing only the unused role will not change that run.

Files are relative to THE ACTIVE ROLE ROOT:
Replace/add tasks/sccm_reinstall.yml
Replace tasks/sccm_patching.yml
Replace tasks/round.yml (preserves latest behavior)
Replace files/client.ps1
Replace files/management.ps1
Optional entry template: tasks/main.yml

Example: if the current active role is windows_upgrade_patching_prerequisite, copy tasks/ and files/ into roles/windows_upgrade_patching_prerequisite/.
Do not blindly replace its main.yml if October tasks are located in another role. Instead retain its existing entry and import sccm_patching.yml ONLY AFTER the existing October role finishes. The supplied sccm_patching.yml imports reinstall at its start, so the call sequence is October -> reinstall -> readiness -> collection/policy -> scan/install/reboot.
If all tasks are in windows_upgrade_sccm_patching and october_patch.yml exists in that role, the supplied tasks/main.yml is suitable. Existing October script and October YAML stay unchanged.
If the role named patching_prerequisite is intentionally run BEFORE October, move its patching invocation after October; a prerequisite pass must not start this reinstall-and-install flow early.

Reinstall behavior:
- Copy the complete site Client folder locally under the domain account.
- Run CCMSetup /noservice /forceinstall from the local folder and wait for actual process completion. Do not delete WMI namespaces or CCM folders manually.
- Exit 0 means setup succeeded; 7 means reboot required. Other codes, including setup already running, stop the workflow.
- Always perform one controlled reboot after the completed reinstall, then wait for CcmExec, SDK classes and the expected site assignment.
- Request fresh policy and rediscovery. Reinstall is performed once per host in a single playbook invocation; a new playbook run will reinstall again.
- Scan ...113 remains the documented scan identifier. A failed scan is never silently replaced with a pass. Policy initialization is retried within the configured scan timeout.
- Fresh WUAHandler scan evidence is still required. WUAHandler.log gets a bounded initialization wait after reinstall.
- Blank TriggerSchedule return values are no longer treated as confirmed success.

Fixed failure reporting and cleanup:
- Rescue propagates the actual PowerShell error list and explicitly fails, allowing the upgrade/Jenkins rescue path to run.
- Existing temporary collection membership/windows are retained after patch failure for investigation.
- Successful cleanup removes membership only if this invocation added it, and only the exact maintenance window created by the invocation.
- Final pending update checks filter non-compliant/error states, rather than requiring all installed update objects to disappear.
- Final status is refreshed after the final reboot.
- Removed invalid preboot_timeout option; fixed the skipped-register overwrite of preflight state.
- Management WMI fallback now queries the configured provider instead of the console host's local WMI namespace.

Existing defaults are used; no mandatory new variables:
sccm_provider_server: homsccmpr01.hanover.com
sccm_site_code: WOR
sccm_allow_reboot: true
Collection and deployment remain unchanged.
The default source resolves to \\homsccmpr01.hanover.com\SMS_WOR\Client.
Optional overrides in existing inventory/group vars:
  sccm_client_source: '\\homsccmpr01.hanover.com\SMS_WOR\Client'
  sccm_client_staging_path: 'C:\WindowsUpgrade\SCCMClient'
  sccm_client_management_point: 'homsccmpr01.hanover.com'
  sccm_client_dns_suffix: 'hanover.com'
  sccm_client_share_password: '{{ vault_windows_password }}'
Without a password override, ansible_password is used. Account must be target admin, allow SYSTEM runas and read the Client share. Existing site-specific TLS, certificate or CMG install requirements must be configured by the SCCM team; this bundle retains the existing intranet site's model.

No current-month or deployment-only filtering is added. Existing client.ps1 installs applicable deployed updates, as in your uploaded code.

After applying:
1. Verify the current playbook role name and order before executing.
2. Syntax-check the playbook on your controller.
3. Run the approved UAT workflow on one server.
4. Confirm tasks Reinstall SCCM client / CCMSetup / readiness occur after October and before Action Scan.
5. If scan 113 still fails, inspect ccmsetup.log, ClientIDManagerStartup.log, PolicyAgent.log, LocationServices.log, ScanAgent.log and WUAHandler.log. Verify site registration, Software Updates enabled and SUP/update-source policy. Do not repeatedly reinstall to work around a server-side policy problem.

Validation here: all YAML parsed and structured workflow/ownership checks passed. No Ansible/PowerShell runtime or SCCM server was available for live execution. Reinstall is a concrete requested change, not a proven diagnosis of the scan-policy failure.

Microsoft references:
https://learn.microsoft.com/en-us/intune/configmgr/core/clients/deploy/about-client-installation-properties
https://learn.microsoft.com/en-us/intune/configmgr/develop/reference/core/clients/client-classes/triggerschedule-method-in-class-sms_client
