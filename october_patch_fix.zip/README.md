October baseline patch fix

Replace these files relative to the project root:
1. roles/windows_upgrade_sccm_patching/tasks/october_patch.yml
2. playbooks/03_upgrade.yml
Add:
3. roles/windows_upgrade_sccm_patching/tasks/october_patch_one.yml

The existing tasks/main.yml remains unchanged. October2022.ps1 is no longer called by this role; it may remain on disk.
The exact three package paths and KB numbers are retained from the supplied project. Their approval, signatures, applicability and vendor authenticity have not been independently verified. The 4.8 and 4.8.1 packages are alternatives, selected by the installed .NET release.

Prerequisites:
- The connection account must be a target local administrator and have read permission on both the source share and NTFS files.
- ansible_password must contain that domain account's password, supplied through the existing Vault/CyberArk mechanism. Never hardcode it. If your password variable has a different name, change the ansible_become_password reference in october_patch_one.yml.
- Existing ansible.windows collection must provide win_hotfix. SYSTEM runas requires the connection account's Windows escalation rights.
- sccm_allow_reboot must be true. Existing defaults already set it true.

Behavior:
- Check Server 2022 build and .NET version.
- Clear a detected servicing reboot before starting.
- Copy applicable packages locally as the domain account and compare SHA-256.
- Install locally as SYSTEM using win_hotfix; stop on failure.
- Reboot after each package when requested, before proceeding.
- Already-present packages are handled by package state rather than requiring UBR to increase.
- CredSSP cleanup moves to the workflow always section, after patching/reporting, including failure paths. No change to enabled_before state policy.

Validation on controller:
ansible-doc ansible.windows.win_hotfix
ansible-playbook -i inventories/uat/hosts.yml playbooks/03_upgrade.yml --syntax-check

Run the existing approved Jenkins workflow against the UAT test server. Syntax-check does not execute upgrades. Local YAML parsing passed; live Windows execution was not available. On failure inspect the exact failed task: stage failure concerns share access, installation failure concerns the local package/servicing context. No automatic retry of failed package installation is performed.
