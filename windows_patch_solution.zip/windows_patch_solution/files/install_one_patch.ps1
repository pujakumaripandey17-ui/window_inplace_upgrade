param(
 [Parameter(Mandatory=$true)][string]$PatchPath,
 [Parameter(Mandatory=$true)][string]$ResultPath
)
$ErrorActionPreference='Stop'
$record=[ordered]@{Finished=$true; Patch=$PatchPath; ExitCode=$null; HexCode=$null; Status='Failed'; Error=''; RebootRequired=$false}
try {
 if (!(Test-Path -LiteralPath $PatchPath -PathType Leaf)) {throw "MSU not found: $PatchPath"}
 $p=Start-Process -FilePath "$env:windir\System32\wusa.exe" -ArgumentList ('"'+$PatchPath+'" /quiet /norestart') -PassThru -Wait -ErrorAction Stop
 $unsigned=[uint32]([int64]$p.ExitCode -band 0xffffffffL)
 $record.ExitCode=[int64]$p.ExitCode
 $record.HexCode=('0x{0:X8}' -f $unsigned)
 switch ($unsigned) {
  0 {$record.Status='Installed'}
  3010 {$record.Status='RebootRequired';$record.RebootRequired=$true}
  2359302 {$record.Status='AlreadyInstalled'}
  default {$record.Status='Failed';$record.Error="WUSA returned $($record.HexCode)"}
 }
} catch {$record.Error=$_.Exception.Message}
$parent=Split-Path -Parent $ResultPath
New-Item -ItemType Directory -Force -Path $parent | Out-Null
$tmp="$ResultPath.tmp"
$record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $tmp -Encoding UTF8
Move-Item -LiteralPath $tmp -Destination $ResultPath -Force
if ($record.Status -eq 'Failed') {exit 1} else {exit 0}
