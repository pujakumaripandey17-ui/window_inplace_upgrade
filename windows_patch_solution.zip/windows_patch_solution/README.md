# Windows Server 2022 offline MSU patching via CredSSP and Scheduled Task

This package changes the execution context, not your original update source or approved KB selection. Your original October2022.ps1 remains your reference; the worker executes its same WUSA /quiet /norestart command **one package at a time** so reboots are safe.

## Prerequisites
- Ansible collections: `ansible.windows`, `community.windows`.
- CredSSP working on target, elevated domain account with read access to the UNC share.
- Windows Server 2022 target, Windows Update servicing healthy, approved MSU packages applicable to build 20348.
- Set the **exact** filenames and **approved order** in `patch.yml`. The screenshot is not sufficiently reliable to transcribe every long filename without risking a typo.
- Verify MSU package order and supersedence with Windows servicing team. Some .NET and cumulative updates may require specific sequencing.
- Backups/snapshots and maintenance window approved; avoid simultaneous Windows Update activity.
- If your share uses a different actual spelling, update `patch_share`.

## Run
1. `cp hosts.ini.example hosts.ini` and edit host, domain user, and certificate settings. Supply password through Ansible Vault/Jenkins.
2. Edit `patch_files` and optionally `expected_build` in `patch.yml`.
3. `ansible-galaxy collection install ansible.windows community.windows`
4. `ansible-playbook -i hosts.ini patch.yml -v`

## What it guarantees / does not
- Files are copied from UNC by the CredSSP session, SHA256 checked, and installed locally by Task Scheduler as SYSTEM.
- Each package runs in its own task and is rebooted before moving to the next when necessary.
- WUSA process exit code is captured in decimal and hexadecimal; failures stop the play.
- `expected_build` can enforce the required final OS build, but exact KB presence is not independently proven by the WUSA exit code. Validate each package identity and applicability with the Windows servicing team; Get-HotFix does not show every update.
- Cannot guarantee success if a package is incompatible, corrupt, superseded, blocked by policy, or servicing is unhealthy.
- Do not re-run a second playbook concurrently against the same host.

## Diagnostics if WUSA still returns 5
- Inspect `C:\Windows\Logs\CBS\CBS.log` and Windows Setup/System event logs.
- Confirm local file ACLs, antivirus/EDR policy, Windows Modules Installer, and Windows Update service state.
- Compare manual elevated account with SYSTEM task behavior.
