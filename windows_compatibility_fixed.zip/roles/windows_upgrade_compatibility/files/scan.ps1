param(
    [Parameter(Mandatory=$true)][string]$IsoPath,
    [Parameter(Mandatory=$true)][string]$ExpectedSha256,
    [Parameter(Mandatory=$true)][string]$LogDirectory,
    [ValidateSet('enable','disable')][string]$DynamicUpdateMode = 'disable'
)
$ErrorActionPreference = 'Stop'
$report = [ordered]@{
    compatible = $false
    reason = 'Not started'
    hostname = $env:COMPUTERNAME
    timestamp_utc = [DateTime]::UtcNow.ToString('o')
    iso_path = $IsoPath
    iso_sha256 = $null
    source_caption = $null
    source_edition = $null
    source_installation_type = $null
    media_images = @()
    target_image = $null
    target_image_index = $null
    exit_code_hex = 'N/A'
    setup_log_directory = $LogDirectory
}
$mountedHere = $false
try {
    New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
    if ($ExpectedSha256 -notmatch '^[a-fA-F0-9]{64}$') { throw 'ExpectedSha256 must be the approved 64-character hexadecimal SHA256.' }
    if (-not (Test-Path -LiteralPath $IsoPath -PathType Leaf)) { throw "ISO file missing: $IsoPath" }
    $actualHash = (Get-FileHash -LiteralPath $IsoPath -Algorithm SHA256 -ErrorAction Stop).Hash
    $report.iso_sha256 = $actualHash
    if ($actualHash -ine $ExpectedSha256) { throw 'ISO SHA256 mismatch; refusing compatibility scan.' }

    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
    $report.source_caption = $os.Caption
    if ([string]$os.Version -notmatch '^10\.0\.14393(\.|$)') { throw "Expected Windows Server 2016 (build 14393); found $($os.Version)." }
    if ([string]$os.OSArchitecture -notmatch '64') { throw 'Source operating system is not 64-bit.' }
    $cv = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
    $report.source_edition = [string]$cv.EditionID
    $report.source_installation_type = [string]$cv.InstallationType
    if ($report.source_edition -ne 'ServerStandard') { throw "Source edition must be ServerStandard; found $($report.source_edition)." }
    if ($report.source_installation_type -ne 'Server') { throw "Source must be Desktop Experience (InstallationType=Server); found $($report.source_installation_type)." }

    $disk = Get-DiskImage -ImagePath $IsoPath -ErrorAction Stop
    if (-not $disk.Attached) {
        Mount-DiskImage -ImagePath $IsoPath -ErrorAction Stop | Out-Null
        $mountedHere = $true
    }
    $volume = Get-DiskImage -ImagePath $IsoPath -ErrorAction Stop | Get-Volume -ErrorAction Stop | Where-Object { $_.DriveLetter } | Select-Object -First 1
    if (-not $volume) { throw 'Mounted ISO has no accessible drive letter.' }
    $root = "$( $volume.DriveLetter ):\".Replace(' ','')
    $setup = Join-Path $root 'setup.exe'
    if (-not (Test-Path -LiteralPath $setup -PathType Leaf)) { throw 'setup.exe missing from ISO root.' }
    $install = @('sources\install.wim','sources\install.esd') | ForEach-Object { Join-Path $root $_ } | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
    if (-not $install) { throw 'install.wim or install.esd missing from ISO.' }

    $images = @(Get-WindowsImage -ImagePath $install -ErrorAction Stop)
    $report.media_images = @($images | Select-Object ImageIndex, ImageName, ImageDescription)
    $targets = @($images | Where-Object {
        $name = ([string]$_.ImageName).Trim()
        $name -match '(?i)^Windows Server 2022 (SERVERSTANDARD|Standard \(Desktop Experience\))$'
    })
    if ($targets.Count -ne 1) { throw "Expected exactly one Windows Server 2022 Standard Desktop Experience image; found $($targets.Count). Inspect media_images." }
    $report.target_image = $targets[0].ImageName
    $report.target_image_index = $targets[0].ImageIndex

    # Use the native Setup compatibility scanner. Exit code 0xC1900210 indicates no blocking issues found.
    $arguments = @('/auto','upgrade','/quiet','/compat','scanonly','/dynamicupdate',$DynamicUpdateMode,'/copylogs',$LogDirectory,'/eula','accept')
    $process = Start-Process -FilePath $setup -ArgumentList $arguments -Wait -PassThru -ErrorAction Stop
    $hex = '0x{0:X8}' -f ([uint32]([int64]$process.ExitCode -band 0xFFFFFFFFL))
    $report.exit_code_hex = $hex
    switch ($hex) {
        '0xC1900210' { $report.compatible = $true; $report.reason = 'Native Windows Setup compatibility scan passed.' }
        '0xC1900208' { $report.reason = 'Application or driver compatibility blocker.' }
        '0xC1900204' { $report.reason = 'Requested migration choice unavailable.' }
        '0xC1900200' { $report.reason = 'System requirements not met.' }
        '0xC190020E' { $report.reason = 'Insufficient free space.' }
        default { $report.reason = "Setup scan returned $hex; inspect Panther and Setup logs." }
    }
}
catch {
    $report.compatible = $false
    $report.reason = $_.Exception.Message
}
finally {
    if ($mountedHere) {
        try { Dismount-DiskImage -ImagePath $IsoPath -ErrorAction Stop | Out-Null }
        catch {
            $report.compatible = $false
            $report.reason = "$($report.reason); ISO dismount failed: $($_.Exception.Message)"
        }
    }
    $report.timestamp_utc = [DateTime]::UtcNow.ToString('o')
    $statusDir = Join-Path (Split-Path -Path $LogDirectory -Parent) 'Status'
    try {
        New-Item -ItemType Directory -Path $statusDir -Force -ErrorAction Stop | Out-Null
        $reportPath = Join-Path $statusDir 'compatibility_report.json'
        $report | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $reportPath -Encoding UTF8 -ErrorAction Stop
    }
    catch {
        $report.compatible = $false
        $report.reason = "$($report.reason); report save failed: $($_.Exception.Message)"
    }
    $Ansible.Result = $report
}
