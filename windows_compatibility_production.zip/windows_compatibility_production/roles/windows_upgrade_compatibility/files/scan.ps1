param(
    [Parameter(Mandatory=$true)][string]$IsoPath,
    [Parameter(Mandatory=$true)][string]$WorkDir,
    [ValidateSet('disable','enable')][string]$DynamicUpdateMode = 'disable',
    [bool]$MediaVerified = $false,
    [int]$TimeoutSeconds = 14400
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$reportDir = Join-Path $WorkDir 'Status'
$logDir = Join-Path $WorkDir 'Logs\Compatibility'
$reportPath = Join-Path $reportDir 'compatibility.json'
$archivePath = Join-Path $reportDir 'compatibility-logs.zip'
$report = [ordered]@{
    hostname=$env:COMPUTERNAME; captured_utc=(Get-Date).ToUniversalTime().ToString('o')
    compatible=$false; status='FAILED'; reason='Not started'; exit_code_hex=$null
    iso_path=$IsoPath; media_verified=$MediaVerified; dynamic_update=$DynamicUpdateMode
    source=@{}; target=@{}; warnings=@(); log_directory=$logDir
}
$mountedHere = $false
$setupProcess = $null
try {
    New-Item -ItemType Directory -Force -Path $reportDir,$logDir | Out-Null
    if (-not $MediaVerified) { throw 'Approved ISO integrity has not been confirmed. Set upgrade_media_verified=true only after verifying SHA256 in the ISO transfer stage.' }
    if (-not (Test-Path -LiteralPath $IsoPath -PathType Leaf)) { throw "ISO not found: $IsoPath" }
    $isoFile = Get-Item -LiteralPath $IsoPath
    if ($isoFile.Length -lt 1GB) { throw 'ISO is unexpectedly small; media approval must be rechecked.' }

    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystem
    $cv = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
    $edition = [string]$cv.EditionID
    $installType = [string]$cv.InstallationType
    $locale = (Get-WinSystemLocale).Name
    $report.source = [ordered]@{ caption=$os.Caption; build=$os.BuildNumber; edition=$edition; installation_type=$installType; locale=$locale; architecture=$os.OSArchitecture }
    if ($os.BuildNumber -ne '14393' -or $os.Caption -notmatch 'Windows Server 2016') { throw "Expected Windows Server 2016 build 14393; found $($os.Caption), build $($os.BuildNumber)." }
    if ($edition -ne 'ServerStandard') { throw "Expected ServerStandard edition; found '$edition'." }
    if ($installType -ne 'Server') { throw "Expected Desktop Experience (InstallationType=Server); found '$installType'." }
    if ($os.OSArchitecture -notmatch '64') { throw 'Source OS must be 64-bit.' }
    if ($cs.DomainRole -ge 4) { throw 'Domain controller requires a separate approved DC upgrade procedure.' }
    $cluster = Get-WindowsFeature -Name Failover-Clustering -ErrorAction Stop
    if ($cluster.Installed) { throw 'Failover clustering installed; requires dedicated cluster upgrade procedure.' }
    $pendingPaths = @(
      'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
      'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
    )
    foreach ($p in $pendingPaths) { if (Test-Path $p) { throw "Pending reboot detected: $p" } }
    $sm = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
    if ($sm -and $sm.PendingFileRenameOperations) { throw 'Pending file rename operations indicate a pending reboot.' }

    $image = Get-DiskImage -ImagePath $IsoPath -ErrorAction Stop
    if (-not $image.Attached) {
        Mount-DiskImage -ImagePath $IsoPath -StorageType ISO -Access ReadOnly -ErrorAction Stop | Out-Null
        $mountedHere = $true
    }
    $vol = Get-DiskImage -ImagePath $IsoPath | Get-Volume | Where-Object DriveLetter | Select-Object -First 1
    if (-not $vol) { throw 'Mounted ISO has no drive letter.' }
    $root = "$($vol.DriveLetter):\"
    $setup = Join-Path $root 'setup.exe'
    if (-not (Test-Path $setup -PathType Leaf)) { throw 'setup.exe missing from mounted ISO.' }
    $wim = Join-Path $root 'sources\install.wim'
    $esd = Join-Path $root 'sources\install.esd'
    $imageFile = if (Test-Path $wim) { $wim } elseif (Test-Path $esd) { $esd } else { throw 'Neither install.wim nor install.esd found.' }
    $images = @(Get-WindowsImage -ImagePath $imageFile -ErrorAction Stop)
    $matching = @($images | Where-Object {
        $_.ImageName -match 'Windows Server 2022' -and
        $_.ImageName -match 'Standard' -and
        $_.ImageName -match 'Desktop Experience' -and
        $_.ImageName -notmatch 'Datacenter|Evaluation'
    })
    if ($matching.Count -ne 1) { throw "Expected exactly one Server 2022 Standard Desktop Experience image; found $($matching.Count). Images: $(($images.ImageName) -join '; ')" }
    $selected = $matching[0]
    $detail = Get-WindowsImage -ImagePath $imageFile -Index $selected.ImageIndex -ErrorAction Stop
    $report.target = [ordered]@{ image_name=$selected.ImageName; image_index=$selected.ImageIndex; image_version=[string]$detail.Version; languages=@($detail.Languages) }
    if ([string]$detail.Version -notmatch '^10\.0\.20348\.') { throw "Target image is not Server 2022 build 20348: $($detail.Version)" }
    $languages = @($detail.Languages | ForEach-Object { [string]$_ })
    if ($languages.Count -gt 0 -and $locale -notin $languages) { throw "Source locale $locale does not match target media languages: $($languages -join ', ')." }
    if ($languages.Count -eq 0) { $report.warnings += 'Target image language metadata unavailable; confirm source/media language match manually.' }

    $arguments = '/Auto Upgrade /Quiet /Compat ScanOnly /DynamicUpdate ' + $DynamicUpdateMode + ' /CopyLogs "' + $logDir + '"'
    $setupProcess = Start-Process -FilePath $setup -ArgumentList $arguments -PassThru -ErrorAction Stop
    if (-not $setupProcess.WaitForExit($TimeoutSeconds * 1000)) {
        $report.reason = "Scan exceeded $TimeoutSeconds seconds; Setup process may still be active. Investigate before retrying."
        throw $report.reason
    }
    $setupProcess.Refresh()
    $code = ('0x{0:X8}' -f ([uint32]([int64]$setupProcess.ExitCode -band 0xFFFFFFFFL)))
    $report.exit_code_hex = $code
    $meanings = @{
      '0xC1900210'='Compatibility scan completed with no reported blockers'
      '0xC1900208'='Application or driver compatibility blocker'
      '0xC1900204'='Requested migration choice unavailable'
      '0xC1900200'='System requirement blocker'
      '0xC190020E'='Insufficient disk space'
    }
    $report.reason = if ($meanings.ContainsKey($code)) { $meanings[$code] } else { "Unexpected Setup exit code $code; inspect Panther logs" }
    $report.compatible = ($code -eq '0xC1900210')
    $report.status = if ($report.compatible) { 'PASS' } else { 'BLOCKED' }
}
catch {
    if ($report.status -eq 'FAILED' -or $report.status -eq 'PASS') { $report.status = 'FAILED' }
    if ($report.reason -eq 'Not started') { $report.reason = $_.Exception.Message }
    if ($report.reason -notmatch [regex]::Escape($_.Exception.Message)) { $report.warnings += $_.Exception.Message }
}
finally {
    # Copy useful Panther evidence before dismounting media.
    $panther = Join-Path $env:SystemRoot 'Panther'
    $setupPanther = 'C:\$WINDOWS.~BT\Sources\Panther'
    foreach ($src in @($panther,$setupPanther)) {
        if (Test-Path $src) {
            $label = if ($src -eq $panther) { 'WindowsPanther' } else { 'SetupPanther' }
            $dest = Join-Path $logDir $label
            New-Item -ItemType Directory -Force -Path $dest | Out-Null
            foreach ($name in @('setupact.log','setuperr.log','CompatData*.xml','*_APPRAISER_HumanReadable.xml')) {
                Get-ChildItem -Path $src -Filter $name -File -ErrorAction SilentlyContinue | ForEach-Object {
                    Copy-Item -LiteralPath $_.FullName -Destination $dest -Force -ErrorAction SilentlyContinue
                }
            }
        }
    }
    if ($mountedHere) {
        try { Dismount-DiskImage -ImagePath $IsoPath -ErrorAction Stop | Out-Null }
        catch { $report.warnings += "Could not dismount ISO: $($_.Exception.Message)" }
    }
    try {
        New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
        $report | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $reportPath -Encoding UTF8 -Force
        if (Test-Path $archivePath) { Remove-Item -LiteralPath $archivePath -Force }
        $logFiles = @(Get-ChildItem -LiteralPath $logDir -Recurse -File -ErrorAction SilentlyContinue)
        if ($logFiles.Count -gt 0) { Compress-Archive -Path (Join-Path $logDir '*') -DestinationPath $archivePath -Force -ErrorAction Stop }
    }
    catch { $report.warnings += "Could not save complete evidence: $($_.Exception.Message)" }
    $Ansible.Changed = $false
    $Ansible.Result = $report
}
