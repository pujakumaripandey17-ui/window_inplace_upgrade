# Windows Server 2016 to 2022 compatibility scan

Run: `ansible-playbook -i inventories/uat/hosts.yml playbooks/02_compatibility.yml`

Place roles in the configured Ansible roles_path. `upgrade_media_verified` defaults to false: set it true ONLY after the media transfer process has verified the approved ISO SHA256 on each target. Never treat file size alone as integrity verification.

Source and target are strictly Windows Server Standard with Desktop Experience. Dynamic Update defaults to disable. Confirm approved target media and Setup compatibility with your organization's OS build and language. The scanner produces a JSON result and best-effort Panther log archive. A scan pass is not an upgrade guarantee. Scan only; no upgrade or reboot is initiated.

Reports: target `C:\WindowsUpgrade\Status\compatibility.json`, controller `reports/compatibility/<host>-compatibility.json`.

For UAT: set `upgrade_media_verified: true` after verifying media, and ensure your service account has elevated local administrator rights. Run one host before batches.
