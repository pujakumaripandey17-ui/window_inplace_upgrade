[CmdletBinding()]
param(
    [ValidateSet('Plan', 'Pending', 'Stage', 'Install', 'Validate')]
    [string]$Action = 'Plan',
    [string]$Source,
    [string]$CacheDirectory = 'C:\Scripts\OctoberBaseline'
)
$ErrorActionPreference = 'Stop'

# Retained from the supplied project: approved October baseline package list.
$patches = @(
    '\\homsqlpr12\Scripts\October\2022\windows10.0-kb5126655-x64_8053239cdb4c4264e6d76017d863cea4a2230804.msu',
    '\\homsqlpr12\Scripts\October\2022\windows10.0-kb5127687-x64-ndp48_ea99577fc39bf62051a7a4c0bdf4ddd69820e62d.msu',
    '\\homsqlpr12\Scripts\October\2022\windows10.0-kb5127693-x64-ndp481_4e84967600fe142948af741fa2b2736f8ed88637.msu'
)
function Test-ServicingReboot {
    return ((Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') -or
        (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'))
}
function Test-KbPresent([string]$Kb) {
    # A failed WMI query must not be mistaken for an absent patch.
    $hotfixes = @(Get-HotFix -ErrorAction Stop)
    return (@($hotfixes | Where-Object HotFixID -EQ $Kb).Count -gt 0)
}
$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
if ($Action -eq 'Pending') {
    @{ reboot_required = [bool](Test-ServicingReboot); changed = $false } | ConvertTo-Json -Compress
    return
}
if ($Action -eq 'Plan') {
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
    if ([int]$os.BuildNumber -ne 20348 -or [int]$os.ProductType -eq 1) {
        throw 'The retained October baseline is intended for Windows Server 2022 (build 20348).'
    }
    $net = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -ErrorAction Stop
    if ([int]$net.Release -lt 528040) { throw 'Expected .NET 4.8 or later; review the baseline.' }
    $has481 = [int]$net.Release -ge 533320
    $selected = @($patches | Where-Object {
        if ($_ -match '-ndp481_') { $has481 }
        elseif ($_ -match '-ndp48_') { -not $has481 }
        else { $true }
    })
    @{ packages = $selected; net_release = [int]$net.Release; identity = $identity; changed = $false } |
        ConvertTo-Json -Compress
    return
}
if ($Source -notin $patches) { throw 'Source is not in the approved baseline list.' }
if ($Source -notmatch '(?i)(kb\d+)') { throw 'Cannot identify KB from package name.' }
$kb = $matches[1].ToUpperInvariant()
$local = Join-Path $CacheDirectory (Split-Path $Source -Leaf)
$result = @{ kb = $kb; identity = $identity; local_path = $local; changed = $false; reboot_required = $false }
if ($Action -eq 'Validate') {
    if (-not (Test-KbPresent $kb)) {
        throw "Cannot confirm $kb after installation/reboot. Review CBS.log and the WUSA log before SCCM."
    }
    $result.status = 'VerifiedInstalled'
    $result | ConvertTo-Json -Compress
    return
}
if (Test-KbPresent $kb) {
    $result.status = 'AlreadyInstalled'
    $result | ConvertTo-Json -Compress
    return
}
if ($Action -eq 'Stage') {
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) {
        throw "Cannot read '$Source' as '$identity'. Check domain credentials, share and NTFS read permissions."
    }
    New-Item -ItemType Directory -Path $CacheDirectory -Force | Out-Null
    $hash = (Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash
    $copyRequired = $true
    if (Test-Path -LiteralPath $local) {
        $copyRequired = (Get-FileHash -LiteralPath $local -Algorithm SHA256).Hash -ne $hash
    }
    if ($copyRequired) { Copy-Item -LiteralPath $Source -Destination $local -Force }
    if ((Get-FileHash -LiteralPath $local -Algorithm SHA256).Hash -ne $hash) {
        throw "Checksum mismatch for $kb after local copy."
    }
    $result.status = 'Staged'
    $result.changed = $copyRequired
    $result.sha256 = $hash
    $result | ConvertTo-Json -Compress
    return
}
# Install only the local file. SYSTEM never accesses the UNC source.
if (-not (Test-Path -LiteralPath $local -PathType Leaf)) { throw "Local package missing: $local" }
if (Test-ServicingReboot) { throw "Pending servicing reboot before $kb; reboot before retrying." }
$mutex = New-Object System.Threading.Mutex($false, 'Global\HanoverOctoberBaseline')
$locked = $false
try {
    $locked = $mutex.WaitOne(0)
    if (-not $locked) { throw 'Another October baseline installation is already running.' }
    $logPath = Join-Path $CacheDirectory ($kb + '-wusa.etl')
    $arguments = '"{0}" /quiet /norestart /log:"{1}"' -f $local, $logPath
    $process = Start-Process -FilePath "$env:SystemRoot\System32\wusa.exe" -ArgumentList $arguments -Wait -PassThru
    $code = [long]$process.ExitCode
    if ($code -lt 0) { $code += 4294967296 }
    $hex = '0x{0:X8}' -f $code
    $result.exit_code = $code
    $result.exit_hex = $hex
    $result.log_path = $logPath
    switch ($code) {
        0       { $result.status = 'Installed'; $result.changed = $true }
        3010    { $result.status = 'InstalledRebootRequired'; $result.changed = $true; $result.reboot_required = $true }
        2359301 { $result.status = 'InstalledRebootRequired'; $result.changed = $true; $result.reboot_required = $true }
        2359302 { $result.status = 'AlreadyInstalled' }
        default {
            throw "October installation failed: KB=$kb exit=$code ($hex) identity=$identity file=$local log=$logPath. Code 5 means access denied. Not-applicable is not treated as success."
        }
    }
    if (Test-ServicingReboot) { $result.reboot_required = $true }
    $result | ConvertTo-Json -Compress
}
finally {
    if ($locked) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}
