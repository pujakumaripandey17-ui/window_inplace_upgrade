October baseline via October2022.ps1, followed by latest SCCM patching

Use this bundle instead of the earlier october_patch_fix.zip.
Extract relative to windows-server-upgrade-uat and replace:
- roles/windows_upgrade_sccm_patching/files/October2022.ps1
- roles/windows_upgrade_sccm_patching/tasks/october_patch.yml
- roles/windows_upgrade_sccm_patching/tasks/main.yml
- playbooks/03_upgrade.yml
Add:
- roles/windows_upgrade_sccm_patching/tasks/october_patch_one.yml

The existing SCCM files, defaults and collection/deployment configuration are unchanged:
Collection: InPlace_Upgrade_Patching
Deployment: InPlace_Upgrade_Servers_Patching
Client installation behavior still follows the existing SCCM code and may install other applicable deployed updates. No current-month filter is added.

The three UNC package paths and KB names are retained from the uploaded source script. Package approvals, signatures and the intended October year/build must be confirmed against your approved baseline; no KB numbers or media have been invented or replaced. Directory name 2022 and script name October2022 are retained exactly. Only the .NET package matching the installed 4.8/4.8.1 version is selected. The other .NET variant is not installed.

What changes:
1. The PowerShell script remains responsible for package selection, staging, WUSA installation and verification.
2. YAML invokes the same script in Plan, Stage, Install and Validate modes. No duplicate package list in YAML.
3. Script copy is synchronized each run, so an old server-side version is replaced.
4. Stage runs as the domain account with explicit credentials. SHA-256 checks confirm the local copy matches the share.
5. Install runs as SYSTEM on local files, bypassing the network dependency during WUSA installation.
6. A required reboot happens between packages, never after blindly submitting all three.
7. Failure stops the role; it cannot continue to SCCM. Error includes KB, exit code, identity and WUSA log path. Not-applicable is a failure requiring review.
8. Already-installed packages are skipped. Selected KBs are checked with Get-HotFix after installation/reboot. If a KB cannot be confirmed, review manually; no success is guessed from UBR changes.
9. CredSSP restore moves into the upgrade playbook's always section after the patching workflow, including failures. It restores the recorded original state.

Requirements:
- Existing account is a target local administrator and can use runas/SYSTEM under your approved policy.
- The same domain account can read both share and NTFS permissions on homsqlpr12.
- Existing ansible_password is used for network staging. If it is stored under a different variable name, set october_share_password to that secret through Vault/CyberArk. Never hardcode it. Example inventory mapping: october_share_password: '{{ vault_windows_password }}'.
- sccm_allow_reboot: true (already in the original defaults).
- Existing ansible.windows modules and Windows PowerShell 5.1.
- One workflow per target at a time. A mutex prevents simultaneous WUSA launches from this script, but does not serialize independent SCCM activity or the entire upgrade.

Controller checks:
ansible-playbook -i inventories/uat/hosts.yml playbooks/03_upgrade.yml --syntax-check
Then use the existing approved Jenkins UAT workflow.

Optional standalone October-only test (does not start SCCM): create a temporary playbook with hosts: windows_upgrade, gather_facts: false and tasks containing include_role with name: windows_upgrade_sccm_patching and tasks_from: october_patch.yml. Limit to one UAT target.
Do not use the full upgrade playbook to test only October patching, because it starts the upgrade workflow.

Diagnostics:
- Stage failure: inspect domain identity, explicit credentials and share/NTFS read permissions.
- Install code 5 on a local file as SYSTEM: inspect local ACLs, endpoint protection policy and CBS/WUSA logs. The original full-versus-single cause is not proven without live results.
- Logs: C:\Scripts\OctoberBaseline\KB<number>-wusa.etl and C:\Windows\Logs\CBS\CBS.log.
- If a newer cumulative patch supersedes an October KB, WUSA may report not-applicable and Get-HotFix may not list that KB. This bundle deliberately stops for baseline review rather than assuming compliance; no supersedence inference is implemented.

Validation performed here: YAML parsing, include paths, retained package-path comparison, and October-before-SCCM ordering checks. No PowerShell/Ansible runtime was installed in this environment; Windows execution and actual error resolution require UAT validation. No target server was changed during preparation.
