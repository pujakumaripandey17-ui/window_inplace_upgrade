# Hanover Windows Server Upgrade — consolidated 14 November 2026

Complete source project assembled from the original full upload and the latest selected updates in this conversation.

**Before use:** retain your current encrypted `inventories/uat/group_vars/all.yml` if newer than the uploaded original. The original Vault-encrypted value is preserved; cleartext passwords, installed virtual environments, downloaded media and historical reports are not bundled.

- [Setup, Jenkins credentials and execution](docs/SETUP.md)
- [Changes, source selection and known limitations](docs/CONSOLIDATION_NOTES.md)
- [Validation performed](docs/VALIDATION.md)
- [Machine-readable changed-file list](docs/CONSOLIDATED_CHANGES.json)

Jenkins form: **CHANGE_ID** and **TARGET_SERVERS** only.

Full workflow: connectivity → assessment → ISO staging → VM discovery/snapshot → compatibility scan → upgrade → services/.NET → October baseline script → original-baseline SCCM reinstall → latest applicable SCCM patching → postchecks/reporting. Original CredSSP state is restored in the workflow's always block.

SCCM cleanup attempts removal of the exact run-created maintenance window and run-added collection rule on both success and failure. The canonical role is `windows_upgrade_sccm_patching`; `windows_upgrade_patching_prerequisite` is a compatibility alias.

**UAT verification is still required.** The prior scan-113/missing Software Updates policy condition is not proven resolved by consolidation. See the notes before running the reinstall reset sequence.
