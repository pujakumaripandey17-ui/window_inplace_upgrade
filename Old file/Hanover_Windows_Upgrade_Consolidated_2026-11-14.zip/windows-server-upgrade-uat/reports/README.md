Generated run reports and verified workbook cache are written here. No historical results are bundled.
