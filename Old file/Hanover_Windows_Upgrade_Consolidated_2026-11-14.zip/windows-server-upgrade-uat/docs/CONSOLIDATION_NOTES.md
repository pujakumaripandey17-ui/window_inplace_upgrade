# Consolidated project — 14 November 2026

This package combines the originally supplied full project with the latest changes available in this conversation. It is a source package; installed virtual environments, downloaded media/workbooks, historical run reports and Windows Zone.Identifier metadata are excluded.

## Included changes

| Area | Consolidated behavior |
|---|---|
| Jenkins form | CHANGE_ID and TARGET_SERVERS only; servers run sequentially; batch stops on failure |
| Credentials | One shared service identity; password remains in your encrypted all.yml; Jenkins supplies the Vault unlock file |
| Discovery | vInfo VM-column lookup, reset_dimensions fix, host-specific controller cache, SHA-256 verified reuse and timings |
| Upgrade | Discovery, snapshot, compatibility, real upgrade, services, .NET, October baseline, reinstall, latest SCCM patching, postchecks |
| CredSSP | Original state restored in the upgrade always block after workflow completion/failure |
| October | October2022.ps1 retained; local staging, SYSTEM installation, .NET variant selection, per-package reboots and KB validation |
| SCCM baseline | Latest supplied-working-baseline restore, not the superseded SYSTEM forceinstall implementation |
| SCCM initialization | Original 5-minute and 10-minute waits, plus original post-reboot readiness checks |
| SCCM failure | Failure propagates to the upgrade and Jenkins |
| SCCM cleanup | On success and failure, remove exact run-created window and run-added direct rule; report cleanup errors |
| Role naming | windows_upgrade_sccm_patching is canonical; windows_upgrade_patching_prerequisite forwards to it |
| Entry points | master.yaml for full workflow; sccm_patching_only.yml for already-upgraded Server 2022 UAT targets |

## Which updates are superseded

The last SCCM choice was the package sccm_working_baseline_restore.zip, based on the uploaded previously working files. This supersedes intermediate sccm_reinstall.yml/client.ps1 variants. The final repository includes one selected implementation rather than several competing versions. The older role name is only a compatibility entry; do not edit files under that role to change SCCM logic.

The canonical SCCM role entry runs October then sccm_patching.yml; the latter imports reinstall once before preflight. Do not add a second reinstall call or run both role names in the same workflow.

## Credential handling and migration

The original vCenter cleartext password is removed. The original all.yml already contains a Vault-encrypted ansible_password value; its encrypted bytes are preserved in this package. If your live encrypted all.yml has changed since the original upload, retain your CURRENT file instead. Both full-file and inline !vault encryption are accepted. The expected decrypted key is ansible_password. Do not replace an encrypted file with all.yml.example.

Windows username remains Hanover\\svcserverdeploy. vcenter_username and vcenter_password reference the same ansible_user/ansible_password, matching the shared-account requirement. Delegated SCCM tasks also use the existing domain identity. If your account lacks permissions in any service, grant the required approved access rather than embedding another password.

Jenkins runtime credential:
- ID: ansible-vault-password
- Type: Secret file
- Content: a file containing the Ansible VAULT DECRYPTION PASSWORD, not the service-account password.

The Azure Repo checkout credential is configured separately in the Pipeline-from-SCM job. It may already exist. No new Windows/vCenter username-password Jenkins binding is required by this consolidated Jenkinsfile. Existing CyberArk governance for the password stored in encrypted inventory remains your organization's responsibility; this file does not implement a new CyberArk API.

The original Jenkins username-password bindings are replaced by Vault-only runtime access. The ANSIBLE_VAULT_PASSWORD_FILE environment variable supplied by Jenkins overrides the controller's local Vault-file setting for those pipeline steps. Local CLI runs use --vault-password-file or the approved ~/.vault_pass setup.

## Latest SCCM limitation remains unresolved

Logs showed client reinstall exit 0, service and site WOR available, but scan schedule 113 failed with Not found. The diagnostic query returned zero CCM_SoftwareUpdatesClientConfig instances in both RequestedConfig and ActualConfig, despite console resultant settings showing Yes.

This consolidation does not claim that condition is fixed. The uploaded old reinstall sequence was restored for a controlled comparison. Real policy receipt, a fresh completed update scan and final compliance are still required; they are not bypassed.

That reinstall retains the supplied baseline's substantial reset: stops services, deletes root\\ccm and root\\sms namespaces and removes CCM/cache folders before reinstalling from the site share. It is not a simple repair. Source readability is checked before the reset starts. Existing backup/change controls still apply. Initialization has at least 15 minutes of fixed waits plus the original post-reboot delay. The original FFORCEBOOT=1 argument is preserved as supplied; no claim is made that it is a valid setup option. Setup service bootstrapping means process return alone is not complete evidence; subsequent client/policy/scan checks remain essential.

Existing client code installs applicable deployed updates. It does not restrict installation to current-month updates or only one deployment's updates. The named deployment is verified before membership/policy work.

## Limits of cleanup and recovery

Cleanup removes only the direct membership rule added by the current invocation and the exact maintenance window created by it. It does not remove pre-existing membership rules. Collection evaluation/console refresh may lag behind rule removal.

Force-abort, controller termination, unreachable SCCM management or connection loss may prevent cleanup completion. No guarantee of cleanup after process termination is made. No automatic snapshot deletion or revert is added by Jenkins; existing recovery playbooks remain available for the approved process.

## Source and validation

The machine-readable docs/CONSOLIDATED_CHANGES.json identifies overlays. Original README retained as docs/ORIGINAL_README.md for historical reference; follow this package's README and docs/SETUP.md for the selected flow.

Validation results are in docs/VALIDATION.md. Local static checks and resolver fixtures do not replace live Ansible, Jenkins or Windows UAT execution. Existing environment-specific ISO path/hash, .NET installer, vCenter trust, WinRM transport and source permissions must be reviewed before use. No infrastructure was changed while producing this package.
