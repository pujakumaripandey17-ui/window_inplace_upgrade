# Setup and execution

1. Extract into a NEW directory. Keep the current project as a rollback copy, including its current encrypted all.yml.
2. The original inline-Vault all.yml is included unchanged. If your live encrypted inventories/uat/group_vars/all.yml has changed, copy that current version over the bundled original. The expected decrypted variable is ansible_password. Never paste the password into Jenkinsfile or group_vars/windows_upgrade.yaml.
3. Review inventories/uat/hosts.yml. Add each requested target under windows_upgrade with its actual ansible_host. Keep the SCCM management host alias homsr01 under sccm.
4. Review inventories/uat/group_vars/windows_upgrade.yaml and role defaults for media paths, approved hashes, DNS/WinRM, vCenter, notifications and service policy. Existing values are carried forward; they are environment-specific.
5. Provision the Linux Jenkins agent labeled ansible-controller with the existing project's dependencies and Ansible collections. Use requirements.txt and requirements.yml, including approved offline installation if internet access is unavailable. No virtual environment is included.
6. Create/reuse Jenkins Secret file credential ID ansible-vault-password containing the Vault unlock password. Configure the Pipeline-from-SCM job for the correct Azure Repo/branch, using your SCM checkout credential. Script Path: Jenkinsfile.
7. Validate on the controller, then run one approved UAT target before a batch.

## Controller checks

From the extracted project root, using your Ansible environment:

```bash
ansible-playbook -i inventories/uat/hosts.yml playbooks/master.yaml --syntax-check --vault-password-file /path/to/your/vault-password-file
```

The path is an example; use the approved existing Vault password file. Do not add the password to the command line.

## Jenkins form

Only two fields:
- CHANGE_ID: e.g. CHG1234567
- TARGET_SERVERS: exact inventory names separated by commas, spaces or new lines

Starting Build starts the REAL upgrade, snapshot/service actions and required reboots. A Change ID is recorded but is not verified against ServiceNow. There are no additional interactive approval prompts. Existing change authorization and maintenance-window confirmation are operational prerequisites.

## Existing Server 2022 patch-only UAT test

This includes the October script, supplied-baseline reinstall, SCCM patching and owned cleanup. It does NOT run the OS upgrade:

```bash
ansible-playbook -i inventories/uat/hosts.yml playbooks/sccm_patching_only.yml --limit PHTWISBTST05 --vault-password-file /path/to/your/vault-password-file -e change_number=CHG1234567
```

Use only the actual approved target/change. The role defaults retain sccm_allow_reboot=true and acknowledgement that all applicable deployed updates may be installed. Do not use master.yaml merely to test SCCM on an already-upgraded server; that is the full upgrade entry.

## Editing the SCCM implementation

Edit roles/windows_upgrade_sccm_patching/ only. The name windows_upgrade_patching_prerequisite remains as a compatibility alias. Calling either entry runs the complete October-plus-SCCM sequence once; never include both.

## Reports

New runs write reports/ and compatibility/cache subdirectories. Jenkins archives JSON/CSV/HTML/TXT reports. No historical success reports or cached inventory workbooks are shipped. Keep each Jenkins job's workspace isolated; concurrent jobs against the same target require operational coordination beyond the same-job concurrency setting.
