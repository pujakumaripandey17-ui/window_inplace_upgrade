"""Jenkins adapter only. Does not modify the CIS role or site configuration."""
import csv
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / '.cis-venv/bin'

def inside(base, value):
    p = (base / value).resolve()
    if not p.is_relative_to(base.resolve()):
        raise ValueError('Paths must stay inside the selected project directory')
    return p

def settings():
    project = inside(ROOT, os.environ.get('PROJECT_DIR', 'rhel9_cis_standard'))
    paths = {k: inside(project, os.environ.get(k, default)) for k, default in (
        ('INVENTORY_FILE', 'inventory.ini'),
        ('PLAYBOOK_FILE', 'playbooks/site.yml'),
        ('SITE_CONFIG', 'config/cis_unix_team_inputs.yml'))}
    for k, p in paths.items():
        if not p.is_file():
            raise ValueError(f'{k} does not exist: {p.relative_to(ROOT)}')
    hosts = [v.strip() for v in os.environ.get('TARGET_HOSTS', '').split(',') if v.strip()]
    if not hosts or any(not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*', h) or h.lower() == 'all' for h in hosts):
        raise ValueError('Enter explicit inventory aliases separated by commas; patterns and all are prohibited')
    ids = [v.strip() for v in os.environ.get('CONTROL_IDS', '').split(',') if v.strip()]
    if any(not re.fullmatch(r'\d+(?:\.\d+)+', i) for i in ids):
        raise ValueError('Invalid control ID')
    phase = os.environ.get('PHASE', 'all')
    if phase not in ['all'] + [f'{i:02}' for i in range(1, 8)]:
        raise ValueError('Invalid phase')
    return project, paths, list(dict.fromkeys(hosts)), ids, phase

def environment(project, report_dir):
    env = os.environ.copy()
    env['ANSIBLE_HOST_KEY_CHECKING'] = 'False'
    env['ANSIBLE_COLLECTIONS_PATH'] = str(ROOT / '.cis-collections')
    env['RHEL9_CIS_CSV_DIR'] = str(report_dir)
    env.pop('RHEL9_CIS_CSV_OUTPUT', None)
    env['ANSIBLE_CALLBACK_PLUGINS'] = str(project / 'callback_plugins')
    env['ANSIBLE_CALLBACKS_ENABLED'] = 'rhel9_cis_csv_v2'
    env['ANSIBLE_ROLES_PATH'] = str(project / 'roles') + ':' + env.get('ANSIBLE_ROLES_PATH', '~/.ansible/roles:/usr/share/ansible/roles:/etc/ansible/roles')
    return env

def call(args, project, env, **kwargs):
    command = [str(BIN / args[0]), *args[1:]]
    vault_password = env.get('CIS_VAULT_PASSWORD')
    if args[0] == 'ansible-galaxy':
        return subprocess.run(command, cwd=project, env=env, check=True, **kwargs)
    if not vault_password:
        raise ValueError('Jenkins Vault credential cis-ansible-vault-password is missing or empty')
    # Each Ansible invocation gets a private password file, including inventory and syntax checks.
    with tempfile.TemporaryDirectory(prefix='jenkins-cis-vault-') as directory:
        os.chmod(directory, 0o700)
        password_file = Path(directory) / 'vault-password'
        fd = os.open(password_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as stream:
            stream.write(vault_password)
            stream.write('\n')
        child_env = env.copy()
        child_env.pop('CIS_VAULT_PASSWORD', None)
        child_env['ANSIBLE_VAULT_PASSWORD_FILE'] = str(password_file)
        return subprocess.run(command, cwd=project, env=child_env, check=True, **kwargs)

def prepare():
    project, paths, hosts, ids, phase = settings()
    for p in [project / 'requirements.yml', project / 'callback_plugins/rhel9_cis_csv_v2.py', project / 'roles/rhel9_cis_standard/tasks/main.yml']:
        if not p.is_file(): raise ValueError(f'Required integration file missing: {p}')
    env = environment(project, ROOT / 'reports/pre_validation')
    call(['ansible-galaxy', 'collection', 'install', '-p', str(ROOT / '.cis-collections'), '-r', str(project / 'requirements.yml')], project, env)
    print('Project files and parameters verified. SSH known_hosts must already be provisioned.', flush=True)

def run(mode):
    project, paths, hosts, ids, phase = settings()
    report = ROOT / 'reports' / {'validate':'pre_validation', 'remediate':'remediation', 'post_validate':'post_validation'}[mode]
    report.mkdir(parents=True, exist_ok=True)
    env = environment(project, report)
    auth = env.get('CIS_SSH_AUTH', 'ssh-agent')
    if auth not in ('ssh-agent', 'password'): raise ValueError('Invalid SSH authentication mode')
    if auth == 'password':
        for key in ['CIS_SSH_USER', 'CIS_SSH_PASSWORD']:
            if not env.get(key): raise ValueError(f'Missing Jenkins credential binding: {key}')
    elif not env.get('SSH_AUTH_SOCK'):
        raise ValueError('SSH agent credential is not bound')
    inventory = call(['ansible-inventory', '-i', str(paths['INVENTORY_FILE']), '--list'], project, env, capture_output=True, text=True)
    inv = json.loads(inventory.stdout)
    known = set(inv.get('_meta', {}).get('hostvars', {}))
    for group in inv.values():
        if isinstance(group, dict): known.update(group.get('hosts', []))
    missing = set(hosts) - known
    if missing: raise ValueError('Aliases not found in inventory: ' + ', '.join(sorted(missing)))
    extra = {
        'cis_operation': 'remediate' if mode == 'remediate' else 'validate',
        'cis_phase': phase, 'cis_requested_control_ids': ids,
        'cis_site_policy_file': str(paths['SITE_CONFIG']),
        'ansible_become': True, 'ansible_become_method': 'sudo', 'ansible_become_flags': '-H -S -n',
        'cis_continue_on_remediation_error': True, 'cis_fail_remediation_when_unresolved': False,
        'cis_msb_post_remediation_enabled': False, 'cis_msb_reset_opasswd': False,
    }
    if auth == 'password':
        extra.update(ansible_user=env['CIS_SSH_USER'], ansible_password=env['CIS_SSH_PASSWORD'])
    if mode == 'remediate' and os.environ.get('RUN_MSB', 'false').lower() == 'true':
        extra.update(cis_msb_post_remediation_enabled=True, cis_msb_reset_opasswd=True)
        source = env.get('CIS_MSB_PASSWORD_SOURCE', 'encrypted-config')
        if source == 'jenkins-credential':
            if not env.get('CIS_AD_USER') or not env.get('CIS_AD_PASSWORD'):
                raise ValueError('MSB requires the AD join Jenkins credential')
            extra.update(cis_msb_ad_join_username=env['CIS_AD_USER'], cis_msb_ad_join_password=env['CIS_AD_PASSWORD'])
        elif source != 'encrypted-config':
            raise ValueError('Unknown MSB password source')
        # With encrypted-config the role include_vars reads the AD fields from Vault. No override.
    # Private ephemeral file outside workspace; never archive secrets or interpolate them into shell commands.
    with tempfile.TemporaryDirectory(prefix='jenkins-cis-') as temp:
        os.chmod(temp, 0o700)
        secret = Path(temp) / 'extra-vars.json'
        fd = os.open(secret, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as stream: json.dump(extra, stream)
        common = ['-i', str(paths['INVENTORY_FILE']), str(paths['PLAYBOOK_FILE']), '--limit', ','.join(hosts), '-e', '@' + str(secret)]
        call(['ansible-playbook', *common, '--syntax-check'], project, env)
        listed = call(['ansible-playbook', *common, '--list-hosts'], project, env, capture_output=True, text=True)
        print(listed.stdout, flush=True)
        # Require every entered alias to match the playbook, not merely the inventory.
        resolved = set(re.findall(r'^\s{6,}(\S+)\s*$', listed.stdout, re.M))
        if resolved != set(hosts):
            raise ValueError('Playbook host selection differs from requested aliases; review --list-hosts output')
        call(['ansible', '-i', str(paths['INVENTORY_FILE']), ','.join(hosts), '-e', '@' + str(secret),
              '-m', 'ansible.builtin.command', '-a', 'sudo -n true', '-e', '{"ansible_become": false}'], project, env)
        call(['ansible-playbook', *common], project, env)
    reports = list(report.rglob('*.csv'))
    if not reports: raise ValueError('No CSV report was produced; check callback configuration and selected scope')
    reported_hosts = set()
    for path in reports:
        with path.open(encoding='utf-8-sig', newline='') as stream:
            reported_hosts.update(r.get('host', '') for r in csv.DictReader(stream))
    if reported_hosts != set(hosts):
        raise ValueError('CSV coverage differs from requested inventory hosts; review missing or unexpected report rows')

def summarize():
    folder = ROOT / 'reports' / ('remediation' if os.environ.get('OPERATION') == 'remediate' else 'pre_validation')
    reports = list(folder.rglob('*.csv'))
    if not reports: raise ValueError('Final validation CSVs are missing')
    findings = False
    for report in reports:
        with report.open(encoding='utf-8-sig', newline='') as stream: rows = list(csv.DictReader(stream))
        if not rows: raise ValueError('A report has no control rows')
        pending = [r for r in rows if r.get('final_status') not in ('COMPLIANT', 'REMEDIATION_COMPLETED')]
        print(f'{report.name}: {len(rows)} controls, {len(pending)} findings')
        findings |= bool(pending)
    # Also retain remediation-stage failures, even if the subsequent validator passes.
    for report in (ROOT / 'reports/remediation').rglob('*.csv'):
        with report.open(encoding='utf-8-sig', newline='') as stream:
            findings |= any(bool(r.get('remediation_error', '').strip()) for r in csv.DictReader(stream))
    return 3 if findings else 0

if __name__ == '__main__':
    try:
        mode = sys.argv[1]
        if mode == 'prepare': prepare()
        elif mode in ('validate', 'remediate', 'post_validate'): run(mode)
        elif mode == 'summarize': sys.exit(summarize())
        else: raise ValueError('Unknown operation')
    except (ValueError, OSError, subprocess.CalledProcessError, KeyError) as error:
        # Do not dump captured inventory, runtime variables or secret-file content.
        if isinstance(error, subprocess.CalledProcessError):
            print(f'Ansible command failed with exit code {error.returncode}; review the task output.', file=sys.stderr)
        else: print(str(error), file=sys.stderr)
        sys.exit(1)
 