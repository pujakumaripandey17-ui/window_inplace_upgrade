# HTML upgrade email update

Copy these TWO files into the existing project (overwrite tasks/main.yml, add the template):

- windows_upgrade_reporting/tasks/main.yml → roles/windows_upgrade_reporting/tasks/main.yml
- windows_upgrade_reporting/templates/upgrade_email.html.j2 → roles/windows_upgrade_reporting/templates/upgrade_email.html.j2

Do not replace the whole project or delete your reporting defaults. This patch uses the reporting task file from Hanover_Windows_Upgrade_Consolidated_2026-11-14.zip. If your reporting tasks have changed since that version, replace only the email task body with the following and copy the template:

```yaml
    subtype: html
    charset: utf-8
    body: "{{ lookup('ansible.builtin.template', role_path + '/templates/upgrade_email.html.j2') }}"
```

Remove the previous multiline plain-text `body` block when applying that smaller edit. Keep host, port, from, to, subject, attach, delegate_to, when and ignore_errors as currently configured. No changes to SMTP variables, Jenkins or SCCM tasks. The email is still sent through community.general.mail. Existing JSON attachment stays attached; the archive is a controller path, not a clickable download or new attachment. DBA backup validation remains Not Performed as in the existing code; this change is presentation only.

Sample_SUCCESS.html and Sample_FAILED.html are previews using the supplied example data, not results of a new upgrade. Success with agent warnings still displays those warnings. Dynamic text is HTML escaped, false health values remain visible, and missing postchecks are omitted.

Validation: YAML parsed; Jinja rendered for success/failure, missing postchecks, unknown status and HTML escaping. No email sent and no live SMTP/Outlook test performed.
