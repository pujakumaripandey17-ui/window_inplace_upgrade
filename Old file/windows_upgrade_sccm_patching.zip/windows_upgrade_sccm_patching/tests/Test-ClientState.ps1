# Dependency-free tests for the actual State function; no SCCM changes.
$ErrorActionPreference = 'Stop'
$path = Join-Path $PSScriptRoot '..\files\client.ps1'
$tokens = $null; $errors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile((Resolve-Path $path), [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | Out-String) }
$function = $ast.Find({param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'State'}, $true)
Invoke-Expression $function.Extent.Text
function Updates { $script:mockUpdates }
function RebootPending { $script:mockReboot }
function Get-HotFix { param($ErrorAction) if ($script:installed) { [pscustomobject]@{HotFixID='KB1234567'} } }
function Check($condition, $message) { if (-not $condition) { throw $message } }
$ExpectedKB='KB1234567'; $MonitorIds=@(); $script:mockReboot=$false; $script:installed=$true
foreach ($state in 0..23) {
    $script:mockUpdates=@([pscustomobject]@{Name='Test CU';ArticleID='1234567';UpdateID='test';ComplianceState=0;EvaluationState=$state;ErrorCode=0;PercentComplete=0})
    $shouldThrow=$state -in @(13,15,16,17,18,19)
    $threw=$false
    try { $s=State } catch { $threw=$true; if (-not $shouldThrow) { throw } }
    Check ($threw -eq $shouldThrow) "Wrong failure behavior for state $state"
    if (-not $threw) {
        Check (-not $s.complete) "Noncompliant state $state marked complete"
        Check ($s.updates[0].StateName) "Missing state name $state"
        Check (($s.active -gt 0) -eq ($state -in @(2,3,4,5,6,7,11))) "Wrong active classification $state"
        Check ($s.reboot -eq ($state -in @(8,9,10))) "Wrong reboot classification $state"
    }
}
$script:mockUpdates=@(); $script:installed=$false
$s=State; Check (-not $s.terminal -and $s.waiting_for_offer) 'Empty SDK must not hide absent latest KB'
$script:installed=$true
$s=State; Check ($s.complete -and $s.terminal) 'Installed KB with clear state should converge'
$script:mockReboot=$true
$s=State; Check (-not $s.complete -and $s.reboot) 'Installed KB with reboot must not complete'
$script:mockReboot=$false
foreach ($case in @(@{state=24;code=0},@{state=1;code=5})) {
    $script:mockUpdates=@([pscustomobject]@{Name='Bad';UpdateID='bad';ComplianceState=0;EvaluationState=$case.state;ErrorCode=$case.code})
    $threw=$false; try { $null=State } catch { $threw=$true }
    Check $threw 'Unknown state/nonzero error must fail'
}
Write-Host 'PASS: all 24 states, empty SDK, pending reboot, installed KB, unknown state and error code.'
