# State-aware SCCM patching role — Server 2022

Replace your entire `roles/windows_upgrade_patching_prerequisite` folder with the folder in this ZIP. Keep your existing inventory, Vault, Jenkinsfile and playbook. October baseline tasks and the supplied reinstall implementation are retained. No hardcoded monthly KB or build is required.

Existing defaults target collection `InPlace_Upgrade_Patching`, deployment `InPlace_Upgrade_Servers_Patching`, site `WOR`. Check the management host and setup-share values against your environment as before. No extra Jenkins form fields are required.

## What changed

* management.ps1 reads AssignedCIs from the configured enabled deployment(s), expands Software Update Groups, and freezes the newest available nonexpired, nonsuperseded Server 2022 x64 OS CU by DatePosted for this run. The title filter matches your Microsoft server operating system version 21H2 screenshot; it excludes .NET, Preview and Dynamic Update. No matching or ambiguous latest update fails explicitly.
* client.ps1 covers all 24 CCM_SoftwareUpdate EvaluationState values (0–23). State 7 is actively installing and is never resubmitted. ErrorCode nonzero, unknown states or unknown compliance fail with update details.
* sccm_patching.yml captures initial build/hotfixes before reinstall. Existing in-flight updates prevent a client reinstall, and an active install must finish before a preflight reboot. The original reinstall runs when there is no in-flight job. Existing pending errors require review rather than a destructive reset.
* round.yml requires fresh scan evidence and the selected latest OS KB installed. Empty SDK results alone cannot produce success. Default maximum rounds increased to 6 to allow exclusive updates and dependencies.
* Final validation checks the selected KB through Get-HotFix, no remaining SDK work, no SCCM/CBS/Windows Update reboot and required services. It reports full build (CurrentBuildNumber.UBR). If the KB was absent at start, the full build must advance; if already installed, unchanged build is valid. Registry build values are only read, never written.
* Existing always cleanup is retained: remove this run's maintenance window and only the direct membership rule owned by this run on both patch success and failure. Preexisting membership is preserved. Unreachable hosts/controller termination cannot be guaranteed by an Ansible always block.

## State handling

| State | Name | Behavior |
|---|---|---|
|0|None|Submit only if noncompliant|
|1|Available|Submit only if noncompliant|
|2|Submitted|Monitor; do not submit again|
|3|Detecting|Monitor|
|4|PreDownload|Monitor|
|5|Downloading|Monitor|
|6|WaitInstall|Monitor|
|7|Installing|Monitor; never resubmit|
|8|PendingSoftReboot|Reboot after active work finishes, then fresh scan|
|9|PendingHardReboot|Reboot after active work finishes, then fresh scan|
|10|WaitReboot|Reboot after active work finishes, then fresh scan|
|11|Verifying|Monitor|
|12|InstallComplete|Require compliance and independent KB evidence; wait if stale|
|13|Error|Fail with details|
|14|WaitServiceWindow|Bounded wait; respect maintenance window|
|15|WaitUserLogon|Fail with session-action diagnostic when noncompliant|
|16|WaitUserLogoff|Fail with session-action diagnostic when noncompliant|
|17|WaitJobUserLogon|Fail with session-action diagnostic when noncompliant|
|18|WaitUserReconnect|Fail with session-action diagnostic when noncompliant|
|19|PendingUserLogoff|Fail with session-action diagnostic when noncompliant|
|20|PendingUpdate|Bounded wait; no forced reset|
|21|WaitingRetry|Bounded wait for SCCM retry; no blind resubmission|
|22|WaitPresModeOff|Bounded wait; do not change presentation mode|
|23|WaitForOrchestration|Bounded wait; do not bypass orchestration|

Poll defaults: 30 seconds x 120 retries per monitoring task (about 60 minutes, plus task execution). Six rounds are an upper bound, not a fixed delay. Existing reinstall has its own waits/reboot. Review defaults/main.yml for timeouts. A stuck wait fails with the last state details; handling every state does not mean forcing blocked updates to succeed.

## Validation and limitations

All YAML parsed locally. `tests/Test-ClientState.ps1` uses the actual State function with mocked SCCM/KB/reboot responses for all states and key regression scenarios; run it in Windows PowerShell 5.1 before UAT. This environment has no PowerShell/Ansible runtime, so Windows execution and live SCCM were not tested here.

The latest update means latest OS CU assigned in the named deployment at preparation time. This does not publish/deploy updates or fetch newer Internet updates. A newer installed superseding CU that removed the exact selected KB from Get-HotFix is intentionally not guessed as success; review the deployment baseline. Target OS is Server 2022 build family 20348; monthly CU normally changes UBR, for example 20348.x to 20348.y.

For your current state 8, allow the controlled reboot and final rescan/validation to complete. Avoid starting another patch job on the same server at the same time. Do not run concurrent jobs on the same shared collection because maintenance windows are collection-wide.

Microsoft reference: https://learn.microsoft.com/en-us/intune/configmgr/develop/reference/core/clients/sdk/ccm_softwareupdate-client-wmi-class
