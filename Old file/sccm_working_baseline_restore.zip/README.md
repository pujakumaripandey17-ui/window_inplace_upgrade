SCCM baseline comparison and targeted restore package

Based on the files supplied as the previously working version:
- sccm_reinstall (1).yml
- client(1).ps1
- sccm_patching (1).yml
- round.yml

Replace in the ACTIVE ROLE (logs show roles/windows_upgrade_patching_prerequisite):
  tasks/sccm_reinstall.yml
  tasks/sccm_patching.yml
  tasks/round.yml
  files/client.ps1
Keep existing files/management.ps1, defaults and October script/tasks.

Entry order MUST remain:
October baseline -> sccm_patching.yml.
The supplied sccm_patching.yml imports sccm_reinstall.yml before its client preflight. Do not also import reinstall separately in main.yml, or it will run twice. No main.yml replacement is supplied because your current entry may run October from a separate role. If main.yml already imports reinstall explicitly, remove only that duplicate import, leaving October before sccm_patching.yml.

Comparison findings:
- Both old and new clients use schedule 113 and require fresh successful WUAHandler scan evidence. The old code does not bypass that scan.
- Original client retries 5 times at 15 seconds on a trigger error; the revised version retried scan triggering for about 15 minutes. This changes failure duration; it does not prove the scan is fixed.
- Original reinstall stops services, resets root\\ccm and root\\sms WMI namespaces, removes CCM/ccmcache, then starts the site-share installer under the connection account.
- Original initialization sequence waits 5 minutes, requests policy, discovery and hardware inventory, then waits another 10 minutes before final checks and reboot.
- Revised reinstall used local staged media and SYSTEM /noservice /forceinstall with shorter readiness checks. These are material changes; logs alone do not prove which caused the missing Software Updates policy.

What is preserved in this package:
- The provided old client reset/install commands, including its root namespace and CCM/cache reset behavior. This is a substantial client reset, not simply a service restart. The original FFORCEBOOT=1 string is retained as supplied; this package does not assert it is a valid CCMSetup option. Ansible still performs the explicit reboot later.
- Source homsccmpr01.hanover.com / SMS_WOR / Client; site WOR, DNSSUFFIX=hanover.com; connection-account runas.
- Both original 5-minute and 10-minute initialization waits, plus the original 5-minute post-reboot delay.
- Original client policy/scan/install/status logic and original round.yml (byte-for-byte).
- Current corrected cleanup and failure propagation. Successful AND failed patching attempt cleanup of the exact run-owned maintenance window and run-added direct membership rule. Both attempts execute; cleanup failures are reported. Unreachable hosts, process termination or force-abort can still prevent completion.

Small corrections:
- Check that the share installer is readable BEFORE the supplied reset steps run.
- Explicit become password mapping to sccm_client_share_password, falling back to ansible_password. Existing Vault/CyberArk supplies the password; no password is embedded here.
- Reinstall task checks the returned setup process exit code; 0/7 are accepted, other codes fail.
- Discovery 003/hardware inventory 001 requests are explicitly best effort; failures warn and do not replace the required policy/scan gates.
- Blank schedule status in client.ps1 is described as unconfirmed submission, rather than claiming success. The caller still requires actual deployment policy and a fresh completed scan.
- Preserve current preflight register fix, remove invalid preboot_timeout option, refresh final status and filter genuinely pending/error updates.

Limits:
- User reports the supplied baseline worked previously; no successful execution log proving the full old flow was supplied.
- Current diagnostics show zero CCM_SoftwareUpdatesClientConfig instances in RequestedConfig and ActualConfig, even though console resultant settings show Yes. That underlying state may persist after this restore. This package does not manufacture a policy instance or disable the scan gate.
- Installing the old baseline is a comparative UAT test, not a guaranteed recovery. First verify backup/snapshot and existing authorization as usual. Do not change client settings and reinstall simultaneously if you need to identify the cause.
- Client setup may bootstrap a service: its process return alone is not full installation evidence. Original initialization, service, namespace, version and setup-log checks remain, followed by actual policy/scan verification. The original setup-log search can match historical entries; successful patching still requires a fresh scan and final compliance.
- Existing client installs applicable deployed updates, not just a date/month-filtered subset.

Validation here:
All YAML parsed; the uploaded round.yml remained byte-for-byte identical; original policy/scan/install logic and initialization waits were compared; cleanup conditions and failure propagation checked. No live Windows, PowerShell or SCCM execution was possible.
